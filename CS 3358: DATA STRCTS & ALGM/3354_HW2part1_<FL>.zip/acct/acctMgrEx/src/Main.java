//import acctMgr.AbstractModel.Account;
//import acctMgr.AbstractModel.OverdrawException;
//import acctMgr.exceptions.OverdrawException;
import acctMgr.AbstractModel.Account;
import acctMgr.exceptions.OverdrawException;
import java.math.BigDecimal;

public class Main {

    public static void main(String[] args) {
        // Create instances of Account
        Account account1 = new Account(123456, "Billy Knee", new BigDecimal("1000.00"));
        Account account2 = new Account(836480, "Blake Maker", new BigDecimal("3002.00"));
        Account account3 = new Account(923416, "Nicholas Star", new BigDecimal("200.00"));


        // Display initial account information for account1
        displayAccountInfo(account1);

        // Test deposit and withdraw methods for account1
        testAccount(account1);

        // Display initial account information for account2
        displayAccountInfo(account2);

        // Test deposit and withdraw methods for account2
        testAccount(account2);

        // Display initial account information for account3
        displayAccountInfo(account3);

        // Test deposit and withdraw methods for account3
        testAccount(account3);
    }

    private static void displayAccountInfo(Account account) {
        System.out.println("Account ID: " + account.getID());
        System.out.println("Account Holder Name: " + account.getName());
        System.out.println("Initial Balance: $" + account.getBalance());
        System.out.println();
    }

    private static void testAccount(Account account) {
        try {
            BigDecimal depositAmount = new BigDecimal("256.00");
            account.deposit(depositAmount);
            System.out.println("Deposit of $" + depositAmount + " successful.");
            System.out.println("Updated Balance: $" + account.getBalance());

            BigDecimal withdrawAmount = new BigDecimal("300.00");
            account.withdraw(withdrawAmount);
            System.out.println("Withdrawal of $" + withdrawAmount + " successful.");
            System.out.println("Updated Balance: $" + account.getBalance());

            BigDecimal overdrawAmount = new BigDecimal("2000.00");
            account.withdraw(overdrawAmount);
            System.out.println("Withdrawal of $" + overdrawAmount + " successful.");
            System.out.println("Updated Balance: $" + account.getBalance());
        } catch (OverdrawException e) {
            System.out.println("OverdrawException test successful: " + e.getMessage());
        } catch (IllegalArgumentException e) {
            System.out.println("Test failed: " + e.getMessage());
        }
        System.out.println();
        System.out.println();
    }
}
