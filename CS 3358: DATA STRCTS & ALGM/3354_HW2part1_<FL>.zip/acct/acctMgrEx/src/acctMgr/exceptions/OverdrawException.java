package acctMgr.exceptions;

/**
 * This exception is thrown when an attempt is made to withdraw more funds
 * from an account than what the available balance is.
 */
public class OverdrawException extends Exception {
    /**
     * Constructs a new OverdrawException with the specific message.
     *
     * @param message the detail message = getMessage()
     */
    public OverdrawException(String message) {
        super(message);
    }
}