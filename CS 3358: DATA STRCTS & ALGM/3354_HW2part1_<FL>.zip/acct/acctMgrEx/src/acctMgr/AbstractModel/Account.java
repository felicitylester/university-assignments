package acctMgr.AbstractModel;

import acctMgr.model.AbstractModel;
import acctMgr.exceptions.OverdrawException;
import java.io.Serializable;
import java.math.BigDecimal;

public class Account extends AbstractModel implements Serializable {
    private int ID;
    private String name;
    private BigDecimal balance;

    /**
     * Constructs an Account object with the specified ID, name, and initial balance.
     *
     * @param ID      the ID of the account
     * @param name    the name of the account holder
     * @param balance the initial balance of the account
     **/
    public Account(int ID, String name, BigDecimal balance) {
        this.ID = ID;
        this.name = name;
        this.balance = balance;
    }

    public Account(String number, String johnDoe) {
        super();
        this.balance = BigDecimal.ZERO;     // initialize balance to zero
    }

    /**
     * Gets the ID of the account.
     *
     * @return the ID of the account
     */
    public int getID() {
        return ID;
    }

    /**
     * Gets the name of the account holder.
     *
     * @return the name of the account holder
     */
    public String getName() {
        return name;
    }

    /**
     * Gets the current balance of the account.
     *
     * @return the current balance of the account
     */
    public BigDecimal getBalance() {
        return balance;
    }

    /**
     * Deposits the specified amount into the account.
     *
     * @param amount the amount to deposit
     */
    public void deposit(BigDecimal amount) {
        balance = balance.add(amount);
    }

    @Override
    public String getId() {
        return null;
    }

    /**
     * Withdraws the specified amount from the account.
     *
     * @param amount the amount to withdraw
     * @throws OverdrawException if the withdrawal amount exceeds the account balance
     */
    public void withdraw(BigDecimal amount) throws OverdrawException {
        if (balance.compareTo(amount) >= 0) {
            balance = balance.subtract(amount);
        } else {
            throw new OverdrawException("You are too broke.");
        }
    }
}
