package acctMgr.AbstractModel;

import java.util.ArrayList;
import java.util.List;

public class AccountList {

    private final List<Account> accounts = new ArrayList<>();

    public AccountList() {
    }

    public void addAccount(Account account) {
        accounts.add(account);
    }

    public void removeAccount(String accountId) {
        accounts.removeIf(account -> account.getId().equals(accountId));
    }

    public boolean containsAccount(String accountId) {
        for (Account account : accounts) {
            if (account.getId().equals(accountId)) {
                return true;
            }
        }
        return false;
    }

    public Account getAccount(String number) {
        for (Account account : accounts) {
            if (account.getId().equals(number)) {
                return account;
            }
        }
        return null;
    }

}


