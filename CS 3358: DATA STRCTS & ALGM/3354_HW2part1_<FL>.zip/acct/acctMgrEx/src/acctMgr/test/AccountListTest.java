package acctMgr.test;

import acctMgr.AbstractModel.Account;
import acctMgr.AbstractModel.AccountList;

/**
 * This class contains test cases for the {@link AccountList} class.
 */
public class AccountListTest {

    /**
     * Runs all the test cases for the {@link AccountList} class.
     *
     * @param args the command-line arguments (not used)
     */
    public static void main(String[] args) {
        testAddAccount();
        testRemoveAccount();
        testGetAccount();
        testRemoveNonExistingAccount();
    }

    /**
     * Tests the addAccount method.
     *
     * Verifies that an account is successfully added to the account list.
     *
     * @throws AssertionError if the test fails
     */
    public static void testAddAccount() throws AssertionError {
        AccountList accountList = new AccountList();
        Account account = new Account("123", "John Doe");
        accountList.addAccount(account);
        // Check if the account was added to the list
        if (!accountList.containsAccount("123")) {
            throw new AssertionError("Add account test failed");
        }
    }

    /**
     * Tests the removeAccount(String) method.
     *
     * Verifies that an account is successfully removed from the account list.
     */
    public static void testRemoveAccount() {
        AccountList accountList = new AccountList();
        Account account = new Account("123", "John Doe");
        accountList.addAccount(account);
        accountList.removeAccount(account.getId()); // Use the account ID for removal
        assert !accountList.containsAccount("123") : "Remove account test failed";
    }

    /**
     * Tests the getAccount(String) method.
     * <p>
     * Verifies that an account can be retrieved from the account list.
     */
    public static void testGetAccount() {
        AccountList accountList = new AccountList();
        Account account = new Account("123", "John Doe");
        accountList.addAccount(account);

        // Retrieve the account from the list
        Account retrievedAccount = accountList.getAccount("123");

        // Check if the retrieved account is not null
        assert retrievedAccount != null : "Get account test failed";
    }

    /**
     * Tests the removeAccount(String) method with a non-existing account.
     * <p>
     * Verifies that removing a non-existing account does not affect the account list.
     */
    public static void testRemoveNonExistingAccount() {
        AccountList accountList = new AccountList();
        Account account = new Account("123", "John Doe");
        accountList.addAccount(account);

        // Attempt to remove a non-existing account
        accountList.removeAccount("821");

        // Verify that the account count remains the same
        Account initialAccountCount = accountList.getAccount("123"); // Get the initial account count
        accountList.removeAccount("821"); // Attempt to remove the non-existing account again
        Account finalAccountCount = accountList.getAccount("123"); // Get the final account count after removal

        // Assert that the initial and final account counts are the same
        assert initialAccountCount == finalAccountCount : "Remove non-existing account test failed";
    }
}
