package acctMgr.test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
        AccountTest.class,
        AccountListTest.class
})
public class CombinedAccountTest {
    // This class doesn't need any code. It's just a container for running the other tests.
}

