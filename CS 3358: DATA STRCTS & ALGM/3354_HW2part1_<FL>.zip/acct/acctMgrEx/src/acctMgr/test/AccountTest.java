package acctMgr.test;

import acctMgr.AbstractModel.Account;
import acctMgr.exceptions.OverdrawException;
import org.junit.Before;
import org.junit.Test;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.*;

public class AccountTest {

    private Account account;

    @Before
    public void setUp() {
        // Initialize account before each test
        account = new Account(123456, "Billy Doe", new BigDecimal("1000.00"));
    }

    @Test
    public void testDeposit() {
        account.deposit(new BigDecimal("500.00"));
        assertEquals(new BigDecimal("1500.00"), account.getBalance());
    }

    @Test
    public void testWithdraw() {
        try {
            account.withdraw(new BigDecimal("300.00"));
            assertEquals(new BigDecimal("700.00"), account.getBalance());
        } catch (OverdrawException e) {
            fail("Unexpected OverdrawException thrown: " + e.getMessage());
        }
    }

    @Test
    public void testWithdrawWithOverdrawException() {
        try {
            account.withdraw(new BigDecimal("1500.00")); // Attempt to withdraw more than balance
            fail("Expected OverdrawException to be thrown");
        } catch (OverdrawException e) {
            assertEquals("You are too broke.", e.getMessage());
        }
    }

    @Test
    public void testAddAndRemoveAccount() {
        // Create a list to store accounts
        List<Account> accountList = new ArrayList<>();

        // Create another account
        Account anotherAccount = new Account(789012, "Julia Yellow", new BigDecimal("2022.00"));

        // Step 1: Add the account to the list
        accountList.add(anotherAccount);

        // Step 2: Ensure that the account is added successfully
        assertTrue("Account should be added to the list", accountList.contains(anotherAccount));

        // Step 3: Remove the account from the list
        boolean removed = accountList.remove(anotherAccount);

        // Step 4: Ensure that the account is removed successfully
        assertTrue("Account should be removed from the list", removed);
        assertFalse("Account should no longer be in the list", accountList.contains(anotherAccount));
    }
}



