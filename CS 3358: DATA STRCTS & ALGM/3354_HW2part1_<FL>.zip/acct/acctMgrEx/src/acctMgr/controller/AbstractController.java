// package declaration
// class belongs to the acctMgr.controller package

package acctMgr.controller;

import acctMgr.model.Model;
import acctMgr.view.View;

public abstract class AbstractController implements Controller {

	private View view;
	private Model model;

	public void setModel(Model model) {
		this.model = model;
	}

	public Model getModel() {
		return model;
	}

	public View getView() {
		return view;
	}

	public void setView(View view) {
		this.view = view;
	}
}

// they allow other classes to set and retrieve
// the model and view components associated with this controller.